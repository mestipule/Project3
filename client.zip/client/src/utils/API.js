import React from "react";
import Maps from "../components/Map/Map";
import InfoWindow from "../components/InfoWindow/InfoWindow";
import Autocomplete from "../components/Autocomplete/Autocomplete";


function App() {
  return (
    <div>
      <Map/>
      
    </div>
  );
}

export default App;
